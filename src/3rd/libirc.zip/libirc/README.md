# libirc
C++ IRC library
